BMG HQ 2D APPROVED PACK - 2026-08-22

Exact Unity Resources target paths:
Assets/Fsp/Art/Resources/BMG/UI/bmg_lobby_modern.jpg
Assets/Fsp/Art/Resources/BMG/Characters/bmg_characters_6_atlas.jpg
Assets/Fsp/Art/Resources/BMG/Weapons/bmg_weapons_5_atlas.jpg

SHA256:
9f4626c532bf369c6723e6ef5834eea1aaa8b2ec8b4ac1cc183b74575e52903a  bmg_lobby_modern.jpg
43343c86884a573d7aa59576f4d76c96f961fadf29c2bedbdf74bce5a586c3b6  bmg_characters_6_atlas.jpg
de6ca146196a177517f655d1f63bc1df944257ea24efa79777544199bad5dcca  bmg_weapons_5_atlas.jpg
